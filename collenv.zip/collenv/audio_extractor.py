import os
import subprocess

def extract_audio(folder):
    for file in os.listdir(folder):
        if file.endswith(".mp4") or file.endswith(".mkv"):
            input_path = os.path.join(folder, file)
            output_path = os.path.join(folder, file.rsplit('.', 1)[0] + ".mp3")
            cmd = f"ffmpeg -i \"{input_path}\" -vn -ar 44100 -ac 2 -b:a 192k \"{output_path}\""
            subprocess.call(cmd, shell=True)

extract_audio(".")