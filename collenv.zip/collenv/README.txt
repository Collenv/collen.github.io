Collenv Tool Pack v0.9.2

📦 What's Inside:
- Audio Batch Extractor (Python): Extracts and normalizes audio from video files.
- Simple Site Starter: A fast GitHub Pages template with WhatsApp lead tools.

🚀 How to Use:
1. Run audio_extractor.py in Pydroid 3 or desktop Python.
2. Customize index.html and style.css in the site_starter folder.
3. Upload to GitHub Pages to launch your site.

🔗 Contact:
Need help or a custom tool? Message me on WhatsApp: wa.me/27720390167

Made with ❤️ by Collen 🇿🇦