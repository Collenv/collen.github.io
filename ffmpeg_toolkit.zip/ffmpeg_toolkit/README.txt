FFmpeg Mobile Toolkit v1.0.0

This toolkit lets you:
- Convert videos to different formats
- Extract audio from video files
- Compress videos to smaller sizes

Requirements:
1. Python installed on your device
2. FFmpeg installed and available in your PATH

How to use:
1. Run the script: python ffmpeg_batch.py
2. Choose an option from the menu:
   - 1 = Convert video
   - 2 = Extract audio
   - 3 = Compress video
   - 4 = Exit
3. Follow the prompts to enter your input and output filenames

Created by Collen