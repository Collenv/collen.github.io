import os

def convert_video():
    input_file = input("Enter video filename: ")
    output_file = input("Enter output filename (e.g. output.mp4): ")
    os.system(f"ffmpeg -i {input_file} {output_file}")

def extract_audio():
    input_file = input("Enter video filename: ")
    output_file = input("Enter output audio (e.g. audio.mp3): ")
    os.system(f"ffmpeg -i {input_file} -q:a 0 -map a {output_file}")

def compress_video():
    input_file = input("Enter video filename: ")
    output_file = input("Enter compressed filename (e.g. small.mp4): ")
    os.system(f"ffmpeg -i {input_file} -vcodec libx265 -crf 28 {output_file}")

while True:
    print("\nFFmpeg Mobile Toolkit")
    print("1. Convert video")
    print("2. Extract audio")
    print("3. Compress video")
    print("4. Exit")
    choice = input("Choose an option: ")

    if choice == "1":
        convert_video()
    elif choice == "2":
        extract_audio()
    elif choice == "3":
        compress_video()
    elif choice == "4":
        break
    else:
        print("Invalid choice. Try again.")